import { TempPage } from '@/components/app/TempPage';

export default function CounselingPage() {
  return <TempPage title="상담관리" />;
}
