import { TempPage } from '@/components/app/TempPage';

export default function CreditInfoPage() {
  return <TempPage title="신용정보" />;
}
