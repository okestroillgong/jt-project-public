import { TempPage } from '@/components/app/TempPage';

export default function ReportsPage() {
  return <TempPage title="보고서" />;
}
