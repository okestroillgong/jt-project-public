import { TempPage } from "@/components/app/TempPage";

export default function UnderConstructionPage() {
  return <TempPage title="페이지 준비중" />;
}
