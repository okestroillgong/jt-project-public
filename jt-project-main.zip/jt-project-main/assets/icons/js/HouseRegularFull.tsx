import * as React from "react";
import type { SVGProps } from "react";
const SvgHouseRegularFull = (props: SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 640" {...props}>
    <path d="M304 70.1c9.1-8.2 22.9-8.2 32 0l232 208c9.9 8.8 10.7 24 1.8 33.9s-24 10.7-33.9 1.8l-8-7.2v205.3c0 35.3-28.7 64-64 64h-288c-35.3 0-64-28.7-64-64V306.6l-8 7.2c-9.9 8.8-25 8-33.9-1.8s-8-25 1.8-33.9zm16 50.1L160 263.7V512c0 8.8 7.2 16 16 16h48V424c0-39.8 32.2-72 72-72h48c39.8 0 72 32.2 72 72v104h48c8.8 0 16-7.2 16-16V263.7L320 120.3zM272 528h96V424c0-13.3-10.7-24-24-24h-48c-13.3 0-24 10.7-24 24z" />
  </svg>
);
export default SvgHouseRegularFull;
